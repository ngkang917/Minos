# kgc2016_SuperSocket
한글
=====
KGC 2016 'SuperSocket' 관련 강연  

이 자료를 본 후 [SuperSocket_Samples](https://github.com/jacking75/SuperSocket_Samples)에 있는 채팅 서버도 보는 것을 추천한다.
  
  
English
=====
KGC 2016 'SuperSocket' Lecture

We recommend viewing the chat server at [SuperSocket_Samples](https://github.com/jacking75/SuperSocket_Samples) after viewing this material.
